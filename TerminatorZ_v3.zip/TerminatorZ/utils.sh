#!/bin/bash

#############################################################################
# TerminatorZ v3.0 - Utilities Module
# Helper functions and dependency management
#############################################################################

# Check and install dependencies
check_dependencies() {
    echo "Checking dependencies..." | lolcat
    
    # Check for gum
    if ! command -v gum &> /dev/null; then
        echo "Installing gum (interactive CLI tool)..." | lolcat
        
        # Detect OS and install gum
        if [[ "$OSTYPE" == "linux-gnu"* ]]; then
            if command -v apt-get &> /dev/null; then
                sudo mkdir -p /etc/apt/keyrings
                curl -fsSL https://repo.charm.sh/apt/gpg.key | sudo gpg --dearmor -o /etc/apt/keyrings/charm.gpg
                echo "deb [signed-by=/etc/apt/keyrings/charm.gpg] https://repo.charm.sh/apt/ * *" | sudo tee /etc/apt/sources.list.d/charm.list
                sudo apt update && sudo apt install -y gum > /dev/null 2>&1
            elif command -v yum &> /dev/null; then
                echo '[charm]
name=Charm
baseurl=https://repo.charm.sh/yum/
enabled=1
gpgcheck=1
gpgkey=https://repo.charm.sh/yum/gpg.key' | sudo tee /etc/yum.repos.d/charm.repo
                sudo yum install -y gum > /dev/null 2>&1
            fi
        elif [[ "$OSTYPE" == "darwin"* ]]; then
            if command -v brew &> /dev/null; then
                brew install gum > /dev/null 2>&1
            fi
        fi
        
        if ! command -v gum &> /dev/null; then
            echo "Could not install gum. Falling back to basic mode." | lolcat
        else
            echo "gum installed successfully!" | lolcat
        fi
    fi
    
    # Install other dependencies
    local deps=("fortune-mod" "lolcat" "curl" "figlet" "toilet" "parallel")
    
    for dep in "${deps[@]}"; do
        if ! command -v $dep &> /dev/null; then
            echo "Installing $dep..." | lolcat
            
            case $dep in
                "fortune-mod")
                    apt-get install -y fortune-mod > /dev/null 2>&1 || true
                    ;;
                "lolcat")
                    pip install lolcat > /dev/null 2>&1 || pip3 install lolcat > /dev/null 2>&1 || gem install lolcat > /dev/null 2>&1 || true
                    ;;
                "curl"|"figlet"|"toilet")
                    apt-get install -y $dep > /dev/null 2>&1 || yum install -y $dep > /dev/null 2>&1 || brew install $dep > /dev/null 2>&1 || true
                    ;;
                "parallel")
                    apt-get install -y parallel > /dev/null 2>&1 || yum install -y parallel > /dev/null 2>&1 || brew install parallel > /dev/null 2>&1 || true
                    ;;
            esac
        fi
    done
    
    # Check for waybackurls
    if ! command -v waybackurls &> /dev/null; then
        echo "Installing waybackurls..." | lolcat
        go install github.com/tomnomnom/waybackurls@latest > /dev/null 2>&1 || true
    fi
    
    # Check for httpx
    if ! command -v httpx &> /dev/null; then
        echo "Installing httpx..." | lolcat
        go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest > /dev/null 2>&1 || true
    fi
    
    echo "Dependencies check complete!" | lolcat
    sleep 1
}

# Progress bar function
show_progress() {
    local current=$1
    local total=$2
    local width=50
    local percentage=$((current * 100 / total))
    local completed=$((width * current / total))
    local remaining=$((width - completed))
    
    printf "\r["
    printf "%${completed}s" | tr ' ' '█'
    printf "%${remaining}s" | tr ' ' '░'
    printf "] %d%% (%d/%d URLs)" $percentage $current $total
}

# Update statistics
update_stats() {
    local severity=$1
    
    case $severity in
        "CRITICAL")
            ((VULN_CRITICAL++))
            ;;
        "HIGH")
            ((VULN_HIGH++))
            ;;
        "MEDIUM")
            ((VULN_MEDIUM++))
            ;;
        "LOW")
            ((VULN_LOW++))
            ;;
    esac
    
    export VULN_CRITICAL VULN_HIGH VULN_MEDIUM VULN_LOW
}

# Calculate ETA
calculate_eta() {
    local current=$1
    local total=$2
    local start_time=$3
    
    local elapsed=$(($(date +%s) - start_time))
    
    if [ $current -eq 0 ]; then
        echo "Calculating..."
        return
    fi
    
    local rate=$((elapsed / current))
    local remaining=$((total - current))
    local eta=$((rate * remaining))
    
    local eta_min=$((eta / 60))
    local eta_sec=$((eta % 60))
    
    printf "%dm %ds" $eta_min $eta_sec
}

# Format time
format_time() {
    local seconds=$1
    local min=$((seconds / 60))
    local sec=$((seconds % 60))
    printf "%dm %ds" $min $sec
}

# Log vulnerability
log_vulnerability() {
    local url=$1
    local vuln_type=$2
    local severity=$3
    local domain=$4
    
    # Color based on severity
    case $severity in
        "CRITICAL")
            color=$RED
            ;;
        "HIGH")
            color=$YELLOW
            ;;
        "MEDIUM")
            color=$CYAN
            ;;
        "LOW")
            color=$WHITE
            ;;
    esac
    
    # Write to file
    echo -e "[$severity] $vuln_type found at $url" >> "$domain/$domain.txt"
    
    # Display
    echo -e "${color}[${severity}]${NC} $vuln_type found at $url"
    
    # Update statistics
    update_stats "$severity"
}

# Display current test
show_current_test() {
    local url=$1
    local vuln_type=$2
    
    echo -e "\n${CYAN}Testing:${NC} $url"
    echo -e "├─ ${vuln_type}..."
}

# Display test result
show_test_result() {
    local vuln_type=$1
    local is_vulnerable=$2
    
    if [ "$is_vulnerable" = "true" ]; then
        echo -e "└─ ${GREEN}VULNERABLE${NC}"
    else
        echo -e "└─ NOT VULNERABLE"
    fi
}

# Display statistics panel
show_statistics() {
    echo ""
    echo "Statistics:"
    echo -e "├─ ${RED}CRITICAL: $VULN_CRITICAL${NC}"
    echo -e "├─ ${YELLOW}HIGH: $VULN_HIGH${NC}"
    echo -e "├─ ${CYAN}MEDIUM: $VULN_MEDIUM${NC}"
    echo -e "└─ ${WHITE}LOW: $VULN_LOW${NC}"
    echo ""
    
    local elapsed=$(($(date +%s) - START_TIME))
    local eta=$(calculate_eta $SCANNED_URLS $TOTAL_URLS $START_TIME)
    
    echo "Time Elapsed: $(format_time $elapsed) | ETA: $eta"
}

# Export functions
export -f show_progress
export -f update_stats
export -f calculate_eta
export -f format_time
export -f log_vulnerability
export -f show_current_test
export -f show_test_result
export -f show_statistics
