#!/bin/bash

#############################################################################
# TerminatorZ v3.0 - Advanced Vulnerability Scanner
# Author: Chris 'SaintDruG' Abou-Chabke
# Organization: Black Hat Ethical Hacking
# Website: https://www.blackhatethicalhacking.com
# Description: Fast passive vulnerability scanner with 31 CVE checks
#############################################################################

VERSION="3.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
WHITE='\033[1;37m'
NC='\033[0m'

# Load modules
source "$SCRIPT_DIR/modules/utils.sh"
source "$SCRIPT_DIR/modules/scanner.sh"
source "$SCRIPT_DIR/modules/reporter.sh"

# Banner and initialization
clear
curl --silent "https://raw.githubusercontent.com/blackhatethicalhacking/Subdomain_Bruteforce_bheh/main/ascii.sh" | lolcat
echo ""

# Sun Tzu quote
quotes=(
  "The supreme art of war is to subdue the enemy without fighting."
  "All warfare is based on deception."
  "He who knows when he can fight and when he cannot, will be victorious."
  "The whole secret lies in confusing the enemy, so that he cannot fathom our real intent."
  "To win one hundred victories in one hundred battles is not the acme of skill. To subdue the enemy without fighting is the acme of skill."
  "Opportunities multiply as they are seized."
  "In the midst of chaos, there is also opportunity."
  "Victorious warriors win first and then go to war, while defeated warriors go to war first and then seek to win."
)
random_quote=${quotes[$RANDOM % ${#quotes[@]}]}
echo "Offensive Security Tip: $random_quote - Sun Tzu" | lolcat
sleep 1
echo "MEANS, IT'S ☕ 1337 ⚡ TIME, 369 ☯ " | lolcat
sleep 1

figlet -w 80 -f small TerminatorZ | lolcat
echo ""
echo "[YOU ARE USING TerminatorZ v$VERSION] - CODED BY Chris 'SaintDruG' Abou-Chabké WITH ❤ FOR blackhatethicalhacking.com" | lolcat
echo "Educational Purposes Only - Authorized Testing Required!" | lolcat
sleep 1
echo "This Version 3.0 checks for a total of 31 vulnerabilities" | lolcat
echo ""

# Check internet connection
tput bold
echo "CHECKING IF YOU ARE CONNECTED TO THE INTERNET!" | lolcat
wget -q --spider https://google.com
if [ $? -ne 0 ]; then
    echo "CONNECT TO THE INTERNET BEFORE RUNNING TerminatorZ!" | lolcat
    exit 1
fi
tput bold
echo "CONNECTION FOUND, LET'S GO!" | lolcat
sleep 1

# Check and install dependencies
check_dependencies

# Main menu
show_main_menu() {
    clear
    echo ""
    echo "╔═══════════════════════════════════════════════════════════╗" | lolcat
    echo "║                                                           ║" | lolcat
    echo "║                   TerminatorZ v3.0                        ║" | lolcat
    echo "║            Advanced Vulnerability Scanner                 ║" | lolcat
    echo "║                                                           ║" | lolcat
    echo "║     Author: Chris 'SaintDruG' Abou-Chabke                ║" | lolcat
    echo "║     Organization: Black Hat Ethical Hacking               ║" | lolcat
    echo "║                                                           ║" | lolcat
    echo "╚═══════════════════════════════════════════════════════════╝" | lolcat
    echo ""
    echo "Select Scan Mode:" | lolcat
    echo ""
    echo "  1. Full Scan (All 31 Checks)" 
    echo "  2. Quick Scan (Top 10 Critical CVEs)"
    echo "  3. Custom Scan (Choose Vulnerabilities)"
    echo "  4. View Previous Reports"
    echo "  5. Exit"
    echo ""
    
    if command -v gum &> /dev/null; then
        CHOICE=$(gum choose "Full Scan" "Quick Scan" "Custom Scan" "View Reports" "Exit")
        case "$CHOICE" in
            "Full Scan") MODE="full" ;;
            "Quick Scan") MODE="quick" ;;
            "Custom Scan") MODE="custom" ;;
            "View Reports") view_reports; return ;;
            "Exit") echo "Goodbye!" | lolcat; exit 0 ;;
        esac
    else
        read -p "Enter choice [1-5]: " choice
        case $choice in
            1) MODE="full" ;;
            2) MODE="quick" ;;
            3) MODE="custom" ;;
            4) view_reports; return ;;
            5) echo "Goodbye!" | lolcat; exit 0 ;;
            *) echo "Invalid choice"; sleep 1; show_main_menu; return ;;
        esac
    fi
    
    start_scan "$MODE"
}

# Start scan function
start_scan() {
    local mode=$1
    
    echo ""
    if command -v gum &> /dev/null; then
        domain=$(gum input --placeholder "Enter target domain (example.com)")
        threads=$(gum input --placeholder "Concurrent threads (1-10)" --value "5")
    else
        read -p "Enter the domain (example.com): " domain
        read -p "Concurrent threads [5]: " threads
        threads=${threads:-5}
    fi
    
    if [ -z "$domain" ]; then
        echo "Domain cannot be empty!" | lolcat
        sleep 2
        show_main_menu
        return
    fi
    
    # Create results directory
    if [ -d "$domain" ]; then
        echo "Error: Directory $domain already exists"
        read -p "Overwrite? [y/n]: " overwrite
        if [ "$overwrite" != "y" ]; then
            show_main_menu
            return
        fi
        rm -rf "$domain"
    fi
    mkdir -p "$domain"
    
    echo ""
    echo "Gathering URLs from Wayback Machine..." | lolcat
    
    # Collect URLs
    waybackurls $domain | grep -E "\.js$|\.php$|\.yml$|\.env$|\.txt$|\.xml$|\.config$|\.json$|\.asp$|\.aspx$" | httpx -silent | sort -u > urls.txt
    
    count=$(wc -l < urls.txt)
    echo "Total URLs found: $count" | lolcat
    
    if [ $count -eq 0 ]; then
        echo "No URLs found for $domain" | lolcat
        sleep 2
        show_main_menu
        return
    fi
    
    # Matrix countdown
    echo "Let us Terminate them in 5 seconds - Matrix Mode ON:" | toilet --metal -f term -F border
    
    R='\033[0;31m'
    G='\033[0;32m'
    Y='\033[1;33m'
    B='\033[0;34m'
    P='\033[0;35m'
    C='\033[0;36m'
    W='\033[1;37m'
    
    for ((i=0; i<5; i++)); do
        echo -ne "${R}10 ${G}01 ${Y}11 ${B}00 ${P}01 ${C}10 ${W}00 ${G}11 ${P}01 ${B}10 ${Y}11 ${C}00\r"
        sleep 0.2
        echo -ne "${R}01 ${G}10 ${Y}00 ${B}11 ${P}10 ${C}01 ${W}11 ${G}00 ${P}10 ${B}01 ${Y}00 ${C}11\r"
        sleep 0.2
        echo -ne "${R}11 ${G}00 ${Y}10 ${B}01 ${P}00 ${C}11 ${W}01 ${G}10 ${P}00 ${B}11 ${Y}10 ${C}01\r"
        sleep 0.2
        echo -ne "${R}00 ${G}11 ${Y}01 ${B}10 ${P}11 ${C}00 ${W}10 ${G}01 ${P}11 ${B}00 ${Y}01 ${C}10\r"
        sleep 0.2
    done
    echo ""
    
    # Start scanning
    echo ""
    echo "╔═══════════════════════════════════════════════════════════╗"
    echo "║ TerminatorZ v3.0 - Scan in Progress                      ║"
    echo "║ Target: $domain | URLs: $count                           ║"
    echo "╚═══════════════════════════════════════════════════════════╝"
    echo ""
    
    # Initialize statistics
    export TOTAL_URLS=$count
    export SCANNED_URLS=0
    export VULN_CRITICAL=0
    export VULN_HIGH=0
    export VULN_MEDIUM=0
    export VULN_LOW=0
    export START_TIME=$(date +%s)
    
    # Run scanner based on mode
    case $mode in
        "full")
            scan_all "$domain" "$threads"
            ;;
        "quick")
            scan_quick "$domain" "$threads"
            ;;
        "custom")
            scan_custom "$domain" "$threads"
            ;;
    esac
    
    # Move results
    mv urls.txt "$domain/"
    
    # Completion message
    echo ""
    echo "╔═══════════════════════════════════════════════════════════╗"
    echo "║                  Scan Complete!                           ║"
    echo "╚═══════════════════════════════════════════════════════════╝"
    echo ""
    echo "Statistics:"
    echo "  CRITICAL: $VULN_CRITICAL"
    echo "  HIGH: $VULN_HIGH"
    echo "  MEDIUM: $VULN_MEDIUM"
    echo "  LOW: $VULN_LOW"
    echo ""
    
    # Generate report
    if command -v gum &> /dev/null; then
        if gum confirm "Generate detailed report?"; then
            generate_report "$domain"
        fi
        
        if gum confirm "View vulnerabilities now?"; then
            cat "$domain/$domain.txt" | lolcat
        fi
    else
        read -p "Generate detailed report? [y/n]: " gen_report
        if [ "$gen_report" = "y" ]; then
            generate_report "$domain"
        fi
        
        read -p "View vulnerabilities now? [y/n]: " view_now
        if [ "$view_now" = "y" ]; then
            cat "$domain/$domain.txt" | lolcat
        fi
    fi
    
    echo ""
    echo "Targets have been T3rm1nat3d... I'll be back!" | lolcat
    echo ""
    
    # Save to scan history
    echo "$(date '+%Y-%m-%d %H:%M:%S') | $domain | $count URLs | C:$VULN_CRITICAL H:$VULN_HIGH M:$VULN_MEDIUM L:$VULN_LOW" >> "$SCRIPT_DIR/results/.scan_history"
    
    read -p "Press Enter to return to main menu..."
    show_main_menu
}

# View previous reports
view_reports() {
    clear
    echo ""
    echo "╔═══════════════════════════════════════════════════════════╗"
    echo "║              Previous Scan Reports                        ║"
    echo "╚═══════════════════════════════════════════════════════════╝"
    echo ""
    
    if [ ! -f "$SCRIPT_DIR/results/.scan_history" ]; then
        echo "No previous scans found."
        read -p "Press Enter to return..."
        show_main_menu
        return
    fi
    
    cat "$SCRIPT_DIR/results/.scan_history" | tail -20
    echo ""
    
    read -p "Enter domain name to view report (or press Enter to go back): " view_domain
    
    if [ -n "$view_domain" ] && [ -d "$view_domain" ]; then
        if [ -f "$view_domain/report.html" ]; then
            echo "Opening HTML report..."
            if command -v xdg-open &> /dev/null; then
                xdg-open "$view_domain/report.html"
            elif command -v open &> /dev/null; then
                open "$view_domain/report.html"
            else
                echo "Report location: $view_domain/report.html"
            fi
        else
            cat "$view_domain/$view_domain.txt"
        fi
    fi
    
    read -p "Press Enter to return to main menu..."
    show_main_menu
}

# Start the tool
show_main_menu
